package storage

import (
	"fmt"

	"28.go/src/student"
)

type Storage struct {
	studentMap map[int]*student.Student
}

func NewStorage(studentMap map[int]*student.Student) *Storage {
	return &Storage{
		studentMap: studentMap,
	}
}

func (s *Storage) Put(student *student.Student, index int) {
	s.studentMap[index] = student
}

func (s *Storage) Get() {
	fmt.Println("\nТекущая карта студентов:")
	for _, student := range s.studentMap {
		fmt.Printf("Имя: %s, Возраст: %d, Оценка: %d\n", student.Name, student.Age, student.Grade)
	}
}
