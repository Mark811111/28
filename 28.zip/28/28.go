package main

import (
	"bufio"
	"fmt"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"

	"28.go/src/storage"
	"28.go/src/student"
)

var exitCh = make(chan struct{})

func main() {
	var studentBase = make(map[int]*student.Student)
	store := storage.NewStorage(studentBase)

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		sig := <-sigCh
		fmt.Println("Получен сигнал:", sig)
		close(exitCh)
	}()

	scanner := bufio.NewScanner(os.Stdin)

	for i := 0; ; i++ {
		fmt.Print("Введите данные студента (Имя Возраст Оценка) или нажмите Ctrl+D(для Windows Ctrl+C) для завершения:")

		if !scanner.Scan() {
			break
		}

		input := scanner.Text()

		if input == "" {
			fmt.Println("Завершение...")
			break
		}

		studentInput := strings.Fields(input)

		if len(studentInput) != 3 {
			fmt.Println("Неверный ввод. Пожалуйста, введите данные студента как 'Имя Возраст Оценка'.")
			continue
		}

		age, errAge := strconv.Atoi(studentInput[1])
		grade, errGrade := strconv.Atoi(studentInput[2])

		if errAge != nil || errGrade != nil {
			fmt.Println("Ошибка преобразования Возраста или Оценки в целое число.")
			continue
		}

		student := student.NewStudent(studentInput[0], age, grade)
		store.Put(student, i)
	}

	store.Get()
}
